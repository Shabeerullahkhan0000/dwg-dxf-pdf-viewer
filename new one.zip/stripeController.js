// Stripe Payment Integration
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const User = require('../models/User');

const PRODUCTS = {
  'pro-monthly': {
    priceId: process.env.STRIPE_PRICE_PRO_MONTHLY,
    amount: 500, // $5.00
  },
  'pro-yearly': {
    priceId: process.env.STRIPE_PRICE_PRO_YEARLY,
    amount: 3000, // $30.00
  },
};

exports.createCheckoutSession = async (req, res) => {
  try {
    const { planType } = req.body;
    const product = PRODUCTS[planType];

    if (!product) {
      return res.status(400).json({ error: 'Invalid plan type' });
    }

    const session = await stripe.checkout.sessions.create({
      customer_email: req.user.email,
      mode: 'subscription',
      line_items: [
        {
          price: product.priceId,
          quantity: 1,
        },
      ],
      success_url: `${process.env.FRONTEND_URL}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/pricing`,
      metadata: {
        userId: req.user._id,
        planType,
      },
    });

    res.json({ sessionId: session.id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.handleWebhook = async (req, res) => {
  const sig = req.headers['stripe-signature'];

  try {
    const event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );

    switch (event.type) {
      case 'checkout.session.completed':
        const session = event.data.object;
        const user = await User.findById(session.metadata.userId);
        if (user) {
          user.plan = session.metadata.planType;
          user.subscriptionId = session.subscription;
          await user.save();
        }
        break;

      case 'customer.subscription.deleted':
        const subscription = event.data.object;
        await User.findOneAndUpdate(
          { subscriptionId: subscription.id },
          { plan: 'free' }
        );
        break;
    }

    res.json({ received: true });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};