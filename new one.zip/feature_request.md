---
name: Feature Request
about: Suggest a feature for the DWG/DXF/PDF Viewer
title: "[FEATURE] "
labels: ["type/enhancement", "status/backlog"]
assignees: ''
---

## Description
Brief description of the feature

## Problem it solves
What problem does this solve?

## Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

## Tasks
- [ ] Task 1
- [ ] Task 2
- [ ] Task 3

## Related Issues
Link to related issues (if any)

## Additional Context
Any additional context or screenshots