// Backend: File Upload & Management Controller
const multer = require('multer');
const path = require('path');
const File = require('../models/File');
const { checkSubscriptionLimit } = require('../middleware/subscriptionCheck');

// Configure multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${file.originalname}`;
    cb(null, uniqueName);
  },
});

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const allowedExtensions = ['.dwg', '.dxf', '.pdf'];
    const fileExt = path.extname(file.originalname).toLowerCase();

    if (allowedExtensions.includes(fileExt)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  },
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
});

exports.uploadFile = [
  upload.single('file'),
  checkSubscriptionLimit('fileUpload'),
  async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }

      const file = new File({
        userId: req.user._id,
        filename: req.file.filename,
        originalName: req.file.originalname,
        fileType: path.extname(req.file.originalname).toLowerCase().slice(1),
        fileSize: req.file.size,
        uploadedAt: new Date(),
      });

      await file.save();

      res.status(201).json({
        message: 'File uploaded successfully',
        file: {
          id: file._id,
          name: file.originalName,
          size: file.fileSize,
          type: file.fileType,
        },
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
];

exports.getFiles = async (req, res) => {
  try {
    const files = await File.find({ userId: req.user._id }).sort({ uploadedAt: -1 });
    res.json({ files });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteFile = async (req, res) => {
  try {
    const { fileId } = req.params;
    const file = await File.findOne({ _id: fileId, userId: req.user._id });

    if (!file) {
      return res.status(404).json({ error: 'File not found' });
    }

    // Delete file from storage
    const fs = require('fs');
    fs.unlinkSync(path.join('uploads/', file.filename));

    // Delete from database
    await File.deleteOne({ _id: fileId });

    res.json({ message: 'File deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.downloadFile = async (req, res) => {
  try {
    const { fileId } = req.params;
    const file = await File.findOne({ _id: fileId, userId: req.user._id });

    if (!file) {
      return res.status(404).json({ error: 'File not found' });
    }

    const filePath = path.join('uploads/', file.filename);
    res.download(filePath, file.originalName);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};