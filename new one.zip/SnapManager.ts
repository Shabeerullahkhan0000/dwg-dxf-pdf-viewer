// Snap Modes Manager
export class SnapManager {
  private snapModes = {
    endpoint: true,
    midpoint: true,
    center: true,
    intersection: true,
    perpendicular: true,
    parallel: true,
    nearest: true,
  };

  private snapRadius = 10; // pixels
  private detectionRadius = 20; // pixels

  toggleSnapMode(mode: string) {
    if (mode in this.snapModes) {
      this.snapModes[mode as keyof typeof this.snapModes] =
        !this.snapModes[mode as keyof typeof this.snapModes];
    }
  }

  checkSnap(x: number, y: number, geometries: any[]): { x: number; y: number; type: string } | null {
    let closest = null;
    let minDistance = this.snapRadius;

    for (const geometry of geometries) {
      // Check endpoint snap
      if (this.snapModes.endpoint) {
        const endpoints = geometry.getEndpoints?.();
        if (endpoints) {
          for (const point of endpoints) {
            const dist = Math.hypot(point.x - x, point.y - y);
            if (dist < minDistance) {
              minDistance = dist;
              closest = { x: point.x, y: point.y, type: 'endpoint' };
            }
          }
        }
      }

      // Check midpoint snap
      if (this.snapModes.midpoint && geometry.type === 'line') {
        const mid = geometry.getMidpoint?.();
        if (mid) {
          const dist = Math.hypot(mid.x - x, mid.y - y);
          if (dist < minDistance) {
            minDistance = dist;
            closest = { x: mid.x, y: mid.y, type: 'midpoint' };
          }
        }
      }

      // Check center snap (circles)
      if (this.snapModes.center && geometry.type === 'circle') {
        const center = geometry.getCenter?.();
        if (center) {
          const dist = Math.hypot(center.x - x, center.y - y);
          if (dist < minDistance) {
            minDistance = dist;
            closest = { x: center.x, y: center.y, type: 'center' };
          }
        }
      }
    }

    return closest;
  }

  setDetectionRadius(radius: number) {
    this.detectionRadius = radius;
  }

  setSnapRadius(radius: number) {
    this.snapRadius = radius;
  }

  getSnapModes() {
    return this.snapModes;
  }
}