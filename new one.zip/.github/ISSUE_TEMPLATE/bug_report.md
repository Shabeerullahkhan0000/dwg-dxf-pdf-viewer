---
name: Bug Report
about: Report a bug in the DWG/DXF/PDF Viewer
title: "[BUG] "
labels: ["type/bug", "status/backlog"]
assignees: ''
---

## Description
Brief description of the bug

## Steps to Reproduce
1. Step 1
2. Step 2
3. Step 3

## Expected Behavior
What should happen

## Actual Behavior
What actually happens

## Screenshots
If applicable, add screenshots or video

## Environment
- **Browser:** (e.g., Chrome 120)
- **OS:** (e.g., Windows 10)
- **Device:** (e.g., Desktop, iPad)
- **App Version:** (e.g., v1.0.0)

## Additional Context
Any other context about the problem