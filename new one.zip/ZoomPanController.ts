// Zoom & Pan Controller
export class ZoomPanController {
  private zoomLevel = 1;
  private panX = 0;
  private panY = 0;
  private canvas: React.RefObject<HTMLCanvasElement>;

  constructor(canvas: React.RefObject<HTMLCanvasElement>) {
    this.canvas = canvas;
    this.setupEventListeners();
  }

  private setupEventListeners() {
    const canvas = this.canvas.current;
    if (!canvas) return;

    // Scroll zoom (desktop)
    canvas.addEventListener('wheel', (e) => this.handleZoom(e));

    // Middle mouse pan
    canvas.addEventListener('mousedown', (e) => {
      if (e.button === 1) this.startPan(e);
    });

    canvas.addEventListener('mousemove', (e) => this.handlePan(e));
    canvas.addEventListener('mouseup', () => this.endPan());

    // Touch zoom (mobile)
    canvas.addEventListener('touchstart', (e) => this.handleTouchStart(e));
    canvas.addEventListener('touchmove', (e) => this.handleTouchMove(e));

    // Double-click zoom to object
    canvas.addEventListener('dblclick', () => this.zoomToFit());
  }

  private handleZoom(e: WheelEvent) {
    e.preventDefault();
    const zoomSpeed = 0.1;
    const delta = e.deltaY > 0 ? -zoomSpeed : zoomSpeed;
    this.zoomLevel = Math.max(0.1, this.zoomLevel + delta);
  }

  private startPan(e: MouseEvent) {
    // Implement pan start
  }

  private handlePan(e: MouseEvent) {
    // Implement pan movement
  }

  private endPan() {
    // Implement pan end
  }

  private handleTouchStart(e: TouchEvent) {
    // Implement touch zoom start
  }

  private handleTouchMove(e: TouchEvent) {
    // Implement touch zoom/pan
  }

  private zoomToFit() {
    // Zoom to fit entire drawing
    this.zoomLevel = 1;
    this.panX = 0;
    this.panY = 0;
  }

  public getZoomLevel() {
    return this.zoomLevel;
  }

  public getPan() {
    return { panX: this.panX, panY: this.panY };
  }
}