// Backend: User Model
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  passwordHash: { type: String, required: true },
  plan: {
    type: String,
    enum: ['free', 'pro-monthly', 'pro-yearly', 'master'],
    default: 'free',
  },
  accountStatus: {
    type: String,
    enum: ['active', 'disabled'],
    default: 'active',
  },
  subscriptionId: { type: String }, // Stripe subscription ID
  twoFactorEnabled: { type: Boolean, default: false },
  twoFactorSecret: { type: String },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('User', userSchema);