// Subscription limits and enforcement
import React, { createContext, useState } from 'react';

interface SubscriptionLimits {
  maxFilesPerSession: number;
  maxAutoMeasurements: number;
  maxManualMeasurements: number;
  maxPDFExports: number;
  maxFileSize: number; // in MB
  allowBatchUpload: boolean;
  allowPDFImport: boolean;
  advancedSnapModes: boolean;
  layerToggle: boolean;
  measurementEditing: boolean;
}

const PLAN_LIMITS: Record<string, SubscriptionLimits> = {
  free: {
    maxFilesPerSession: 1,
    maxAutoMeasurements: 10,
    maxManualMeasurements: 20,
    maxPDFExports: 5,
    maxFileSize: 5,
    allowBatchUpload: false,
    allowPDFImport: false,
    advancedSnapModes: true,
    layerToggle: false,
    measurementEditing: false,
  },
  'pro-monthly': {
    maxFilesPerSession: Infinity,
    maxAutoMeasurements: Infinity,
    maxManualMeasurements: Infinity,
    maxPDFExports: Infinity,
    maxFileSize: 50,
    allowBatchUpload: true,
    allowPDFImport: true,
    advancedSnapModes: true,
    layerToggle: true,
    measurementEditing: true,
  },
  'pro-yearly': {
    maxFilesPerSession: Infinity,
    maxAutoMeasurements: Infinity,
    maxManualMeasurements: Infinity,
    maxPDFExports: Infinity,
    maxFileSize: 50,
    allowBatchUpload: true,
    allowPDFImport: true,
    advancedSnapModes: true,
    layerToggle: true,
    measurementEditing: true,
  },
  master: {
    maxFilesPerSession: Infinity,
    maxAutoMeasurements: Infinity,
    maxManualMeasurements: Infinity,
    maxPDFExports: Infinity,
    maxFileSize: Infinity,
    allowBatchUpload: true,
    allowPDFImport: true,
    advancedSnapModes: true,
    layerToggle: true,
    measurementEditing: true,
  },
};

interface SubscriptionContextType {
  getLimits: (plan: string) => SubscriptionLimits;
  canMeasure: (plan: string, type: 'auto' | 'manual', currentCount: number) => boolean;
}

export const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const getLimits = (plan: string): SubscriptionLimits => PLAN_LIMITS[plan] || PLAN_LIMITS.free;

  const canMeasure = (plan: string, type: 'auto' | 'manual', currentCount: number): boolean => {
    const limits = getLimits(plan);
    const limit = type === 'auto' ? limits.maxAutoMeasurements : limits.maxManualMeasurements;
    return currentCount < limit;
  };

  return (
    <SubscriptionContext.Provider value={{ getLimits, canMeasure }}>
      {children}
    </SubscriptionContext.Provider>
  );
};

export const useSubscription = () => {
  const context = React.useContext(SubscriptionContext);
  if (!context) throw new Error('useSubscription must be used within SubscriptionProvider');
  return context;
};