// Core Viewer Component with Canvas Rendering
import React, { useRef, useEffect, useState } from 'react';
import { MeasurementTool } from './tools/MeasurementTool';
import { SnapManager } from './tools/SnapManager';
import { ZoomPanController } from './tools/ZoomPanController';
import './Viewer.css';

interface ViewerProps {
  fileUrl: string;
  fileType: 'dwg' | 'dxf' | 'pdf';
  scale: 'meters' | 'mm' | 'feet';
}

export const Viewer: React.FC<ViewerProps> = ({ fileUrl, fileType, scale }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [measurements, setMeasurements] = useState<any[]>([]);
  const [snapMode, setSnapMode] = useState<string>('endpoint');
  const [zoomLevel, setZoomLevel] = useState(1);
  const [panX, setPanX] = useState(0);
  const [panY, setPanY] = useState(0);

  const zoomPanController = useRef(new ZoomPanController(canvasRef));
  const snapManager = useRef(new SnapManager());
  const measurementTool = useRef(new MeasurementTool(canvasRef, snapManager.current));

  useEffect(() => {
    const loadFile = async () => {
      try {
        // Load DWG/DXF/PDF based on fileType
        const response = await fetch(fileUrl);
        const arrayBuffer = await response.arrayBuffer();

        if (fileType === 'dwg' || fileType === 'dxf') {
          // Use DXF.js or similar library
          console.log('Loading DWG/DXF file...');
          // const dxf = new DXF.File(arrayBuffer);
          // renderDXF(dxf);
        } else if (fileType === 'pdf') {
          // Use PDF.js
          console.log('Loading PDF file...');
          // renderPDF(arrayBuffer);
        }

        renderCanvas();
      } catch (error) {
        console.error('Error loading file:', error);
      }
    };

    loadFile();
  }, [fileUrl, fileType]);

  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Apply zoom and pan transforms
    ctx.save();
    ctx.translate(canvas.width / 2 + panX, canvas.height / 2 + panY);
    ctx.scale(zoomLevel, zoomLevel);

    // Draw measurements
    measurements.forEach((measurement) => {
      drawMeasurement(ctx, measurement);
    });

    ctx.restore();
  };

  const drawMeasurement = (ctx: CanvasRenderingContext2D, measurement: any) => {
    const { startX, startY, endX, endY, length, type } = measurement;

    // Draw dimension line
    ctx.strokeStyle = '#0066cc';
    ctx.lineWidth = 1 / zoomLevel;
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(endX, endY);
    ctx.stroke();

    // Draw measurement text
    ctx.fillStyle = '#0066cc';
    ctx.font = `${12 / zoomLevel}px Arial`;
    ctx.fillText(`${length.toFixed(2)} ${scale}`, (startX + endX) / 2, (startY + endY) / 2 - 10);
  };

  const handleAddMeasurement = (measurement: any) => {
    setMeasurements([...measurements, measurement]);
    renderCanvas();
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Update snap preview
    snapManager.current.checkSnap(x, y);
    renderCanvas();
  };

  return (
    <div className="viewer-container">
      <div className="viewer-toolbar">
        <button onClick={() => setSnapMode('endpoint')}>Endpoint</button>
        <button onClick={() => setSnapMode('midpoint')}>Midpoint</button>
        <button onClick={() => setSnapMode('center')}>Center</button>
        <button onClick={() => setSnapMode('perpendicular')}>Perpendicular</button>
        <button onClick={() => measurementTool.current.toggleAutoMeasure()}>Auto Measure</button>
      </div>

      <canvas
        ref={canvasRef}
        className="viewer-canvas"
        width={1200}
        height={800}
        onMouseMove={handleMouseMove}
        onClick={(e) => measurementTool.current.onClick(e)}
      />

      <div className="measurements-panel">
        <h3>Measurements ({measurements.length})</h3>
        <ul>
          {measurements.map((m, idx) => (
            <li key={idx}>
              {m.length.toFixed(2)} {scale} {m.type && `(${m.type})`}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};