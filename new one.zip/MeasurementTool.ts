// Manual Measurement Tool
import { SnapManager } from './SnapManager';

export class MeasurementTool {
  private canvas: React.RefObject<HTMLCanvasElement>;
  private snapManager: SnapManager;
  private isDrawing = false;
  private startPoint = { x: 0, y: 0 };
  private currentPoint = { x: 0, y: 0 };
  private measurements: any[] = [];
  private autoMeasureEnabled = false;

  constructor(canvas: React.RefObject<HTMLCanvasElement>, snapManager: SnapManager) {
    this.canvas = canvas;
    this.snapManager = snapManager;
  }

  onClick(e: React.MouseEvent) {
    const rect = this.canvas.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (!this.isDrawing) {
      this.startPoint = { x, y };
      this.isDrawing = true;
    } else {
      this.currentPoint = { x, y };
      this.completeMeasurement();
      this.isDrawing = false;
    }
  }

  private completeMeasurement() {
    const length = Math.hypot(
      this.currentPoint.x - this.startPoint.x,
      this.currentPoint.y - this.startPoint.y
    );

    const measurement = {
      startX: this.startPoint.x,
      startY: this.startPoint.y,
      endX: this.currentPoint.x,
      endY: this.currentPoint.y,
      length: length,
      type: 'manual',
      timestamp: new Date(),
    };

    this.measurements.push(measurement);
  }

  toggleAutoMeasure() {
    this.autoMeasureEnabled = !this.autoMeasureEnabled;
  }

  getMeasurements() {
    return this.measurements;
  }

  deleteMeasurement(index: number) {
    this.measurements.splice(index, 1);
  }

  editMeasurement(index: number, updates: any) {
    this.measurements[index] = { ...this.measurements[index], ...updates };
  }
}