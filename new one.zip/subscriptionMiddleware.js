// Subscription Enforcement Middleware
const PLAN_LIMITS = {
  free: {
    maxFilesPerSession: 1,
    maxAutoMeasurements: 10,
    maxManualMeasurements: 20,
    maxPDFExports: 5,
    maxFileSize: 5 * 1024 * 1024, // 5MB
  },
  'pro-monthly': {
    maxFilesPerSession: Infinity,
    maxAutoMeasurements: Infinity,
    maxManualMeasurements: Infinity,
    maxPDFExports: Infinity,
    maxFileSize: 50 * 1024 * 1024, // 50MB
  },
  'pro-yearly': {
    maxFilesPerSession: Infinity,
    maxAutoMeasurements: Infinity,
    maxManualMeasurements: Infinity,
    maxPDFExports: Infinity,
    maxFileSize: 50 * 1024 * 1024, // 50MB
  },
  master: {
    maxFilesPerSession: Infinity,
    maxAutoMeasurements: Infinity,
    maxManualMeasurements: Infinity,
    maxPDFExports: Infinity,
    maxFileSize: Infinity,
  },
};

exports.checkSubscriptionLimit = (action) => {
  return async (req, res, next) => {
    try {
      const userPlan = req.user.plan || 'free';
      const limits = PLAN_LIMITS[userPlan];

      if (!limits) {
        return res.status(400).json({ error: 'Invalid subscription plan' });
      }

      // Check file size limit
      if (action === 'fileUpload' && req.file) {
        if (req.file.size > limits.maxFileSize) {
          return res.status(413).json({
            error: `File exceeds size limit of ${limits.maxFileSize / 1024 / 1024}MB`,
          });
        }
      }

      // Check measurement limits
      if (action === 'addMeasurement') {
        const measurementType = req.body.type; // 'auto' or 'manual'
        const limit =
          measurementType === 'auto'
            ? limits.maxAutoMeasurements
            : limits.maxManualMeasurements;

        if (req.user.currentMeasurementCount >= limit) {
          return res.status(403).json({
            error: `${measurementType} measurement limit reached`,
          });
        }
      }

      // Check PDF export limit
      if (action === 'exportPDF') {
        if (req.user.pdfExportCount >= limits.maxPDFExports) {
          return res.status(403).json({
            error: 'PDF export limit reached',
          });
        }
      }

      next();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };
};